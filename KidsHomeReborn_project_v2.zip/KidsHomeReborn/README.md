# Kids Home Reborn — protótipo 0.2

Atualização com gestos laterais animados, efeitos sonoros extraídos dos recursos fornecidos, música de fundo em loop com controle de som, gaveta de aplicativos instalados e registro como opção de app de início (launcher) do Android.

## Importante
- Este projeto é uma recriação em andamento, não uma cópia completa do Kids Home original.
- A opção de launcher fica disponível no Android; para substituir a tela inicial, escolha **Kids Home Reborn** quando o sistema perguntar ou use o botão Menu > Definir como tela inicial.
- A compatibilidade e o comportamento devem ser testados no dispositivo real.
