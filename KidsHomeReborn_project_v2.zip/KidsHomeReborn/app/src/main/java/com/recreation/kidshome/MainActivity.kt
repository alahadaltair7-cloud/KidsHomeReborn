package com.recreation.kidshome

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var scene: FrameLayout
    private lateinit var title: TextView
    private var page = 0
    private var downX = 0f
    private var downY = 0f
    private var music: MediaPlayer? = null
    private lateinit var sounds: SoundPool
    private var tapSound = 0
    private var swipeSound = 0
    private var appSound = 0
    private var cameraSound = 0
    private var settingsSound = 0
    private var musicEnabled = true
    private val catFrames = intArrayOf(
        R.drawable.kids_character_brown_cat_01,
        R.drawable.kids_character_brown_cat_02,
        R.drawable.kids_character_brown_cat_05,
        R.drawable.kids_character_brown_cat_06,
        R.drawable.kids_character_brown_cat_07
    )
    private var catFrame = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(105, 190, 232)
        window.navigationBarColor = Color.rgb(72, 150, 205)
        setupAudio()
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(125, 205, 240)) }
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.kids_home_bg_sky_day)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Cenário Kids Home"
        }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        scene = FrameLayout(this)
        root.addView(scene, FrameLayout.LayoutParams(-1, -1))
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (abs(dx) > dp(65) && abs(dx) > abs(dy) * 1.2f) {
                        changePage(if (dx < 0) 1 else -1); true
                    } else false
                }
                else -> false
            }
        }
        setContentView(root)
        renderPage(0, false)
        startMusic()
    }

    private fun setupAudio() {
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        sounds = SoundPool.Builder().setMaxStreams(5).setAudioAttributes(attrs).build()
        tapSound = sounds.load(this, R.raw.browncat_tap, 1)
        swipeSound = sounds.load(this, R.raw.carousel_move_1, 1)
        appSound = sounds.load(this, R.raw.application, 1)
        cameraSound = sounds.load(this, R.raw.camera, 1)
        settingsSound = sounds.load(this, R.raw.settings, 1)
    }

    private fun startMusic() {
        if (!musicEnabled || music != null) return
        try {
            music = MediaPlayer.create(this, R.raw.bgm)?.apply {
                isLooping = true
                setVolume(0.32f, 0.32f)
                start()
            }
        } catch (_: Exception) { music = null }
    }

    private fun play(sound: Int) { if (sound != 0) sounds.play(sound, 0.8f, 0.8f, 1, 0, 1f) }

    private fun changePage(direction: Int) {
        val next = (page + direction + 3) % 3
        play(swipeSound)
        val width = root.width.toFloat().coerceAtLeast(1f)
        scene.animate().cancel()
        scene.animate().translationX(if (direction > 0) -width else width).alpha(0.35f).setDuration(130).withEndAction {
            page = next
            renderPage(next, false)
            scene.translationX = if (direction > 0) width else -width
            scene.alpha = 0.35f
            scene.animate().translationX(0f).alpha(1f).setDuration(220).setInterpolator(AccelerateDecelerateInterpolator()).start()
        }.start()
    }

    private fun renderPage(which: Int, animate: Boolean) {
        scene.removeAllViews()
        title = TextView(this).apply {
            text = when (which) { 0 -> "Kids Home"; 1 -> "Meus aplicativos"; else -> "Mundo Kids Home" }
            textSize = 25f
            setTextColor(Color.WHITE)
            setShadowLayer(4f, 2f, 2f, Color.DKGRAY)
            gravity = Gravity.CENTER
        }
        val titleParams = FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        titleParams.topMargin = dp(8)
        scene.addView(title, titleParams)
        when (which) {
            0 -> addHomeCharacter()
            1 -> addAppDrawer()
            else -> addCardsPage()
        }
        addBottomControls()
    }

    private fun addHomeCharacter() {
        val character = ImageView(this).apply {
            setImageResource(catFrames[catFrame])
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Gato marrom animado"
            setOnClickListener {
                play(tapSound)
                catFrame = (catFrame + 1) % catFrames.size
                setImageResource(catFrames[catFrame])
                animate().scaleX(1.06f).scaleY(1.06f).setDuration(110).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                }.start()
            }
        }
        val p = FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.76f).toInt(), (resources.displayMetrics.heightPixels * 0.40f).toInt(), Gravity.CENTER)
        p.topMargin = -dp(10)
        scene.addView(character, p)
        val hint = TextView(this).apply {
            text = "Toque no gatinho • Deslize para os lados"
            textSize = 13f; setTextColor(Color.WHITE); setShadowLayer(3f, 1f, 1f, Color.DKGRAY); gravity = Gravity.CENTER
        }
        val hp = FrameLayout.LayoutParams(-1, dp(30), Gravity.BOTTOM)
        hp.bottomMargin = dp(104)
        scene.addView(hint, hp)
    }

    private fun addCardsPage() {
        val cards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(16), 0, dp(16), 0) }
        addCard(cards, R.drawable.kids_home_card_mypet_big, "Meu Pet") { showMessage("Meu Pet", "A área Meu Pet será conectada numa próxima etapa.") }
        addCard(cards, R.drawable.kids_home_card_planet_big, "Planeta Kids") { showMessage("Planeta Kids", "A área Planeta Kids será conectada numa próxima etapa.") }
        addCard(cards, R.drawable.kids_home_card_gallery_big, "Galeria") { showMessage("Galeria", "A galeria original ainda não foi reconstruída.") }
        val p = FrameLayout.LayoutParams(-1, -1)
        p.topMargin = dp(65); p.bottomMargin = dp(100)
        scene.addView(cards, p)
    }

    private fun addCard(parent: LinearLayout, drawable: Int, label: String, action: () -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(Color.argb(220,255,255,255), dp(18)); setPadding(dp(12), dp(6), dp(12), dp(6)); isClickable = true; setOnClickListener { play(tapSound); action() } }
        val img = ImageView(this).apply { setImageResource(drawable); scaleType = ImageView.ScaleType.FIT_CENTER }
        row.addView(img, LinearLayout.LayoutParams(dp(76), dp(62)))
        row.addView(TextView(this).apply { text = label; textSize = 18f; setTextColor(Color.rgb(45,85,120)); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12),0,0,0) }, LinearLayout.LayoutParams(0, dp(62), 1f))
        val lp = LinearLayout.LayoutParams(-1, dp(76)); lp.setMargins(0, dp(5), 0, dp(5)); parent.addView(row, lp)
    }

    private fun addAppDrawer() {
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(8)) }
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(query, 0).sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        for (info in apps) {
            if (info.activityInfo.packageName == packageName) continue
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(Color.argb(220,255,255,255), dp(14)); setPadding(dp(12), dp(5), dp(12), dp(5)); isClickable = true; setOnClickListener {
                play(tapSound)
                val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launch != null) try { startActivity(launch) } catch (_: Exception) { showMessage("Aplicativo", "Não foi possível abrir este aplicativo.") }
            } }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)) }
            row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            row.addView(TextView(this).apply { text = info.loadLabel(packageManager); textSize = 15f; setTextColor(Color.DKGRAY); setPadding(dp(12),0,0,0) }, LinearLayout.LayoutParams(0, dp(48), 1f))
            val lp = LinearLayout.LayoutParams(-1, dp(56)); lp.setMargins(0, dp(3), 0, dp(3)); list.addView(row, lp)
        }
        if (apps.isEmpty()) list.addView(TextView(this).apply { text = "Nenhum aplicativo encontrado"; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 16f })
        scroll.addView(list)
        val p = FrameLayout.LayoutParams(-1, -1); p.topMargin = dp(68); p.bottomMargin = dp(105)
        scene.addView(scroll, p)
    }

    private fun addBottomControls() {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(5), dp(8), dp(5)); background = rounded(Color.argb(220,255,255,255), dp(24)) }
        addButton(bar, R.drawable.kids_home_button_applications, "Apps") { play(appSound); changePageTo(1) }
        addButton(bar, R.drawable.kids_home_button_camera, "Câmera") { play(cameraSound); showMessage("Câmera", "A câmera original ainda não foi integrada.") }
        addButton(bar, R.drawable.kids_home_button_settings, "Menu") { play(settingsSound); showSettings() }
        addButton(bar, R.drawable.kids_home_button_volume, if (musicEnabled) "Som: ligado" else "Som: desligado") {
            musicEnabled = !musicEnabled
            if (musicEnabled) startMusic() else { music?.stop(); music?.release(); music = null }
            if (musicEnabled) play(settingsSound)
            renderPage(page, false)
        }
        val p = FrameLayout.LayoutParams(-1, dp(82), Gravity.BOTTOM); p.setMargins(dp(12), 0, dp(12), dp(12)); scene.addView(bar, p)
    }

    private fun addButton(parent: LinearLayout, res: Int, label: String, action: () -> Unit) {
        val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true; isFocusable = true; setOnClickListener { action() } }
        item.addView(ImageView(this).apply { setImageResource(res); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(38), dp(38)))
        item.addView(TextView(this).apply { text = label; textSize = 9f; setTextColor(Color.rgb(50,70,90)); gravity = Gravity.CENTER; maxLines = 1 }, LinearLayout.LayoutParams(-1, dp(20)))
        parent.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
    }

    private fun changePageTo(next: Int) {
        val direction = if (next == page) 1 else if (next > page || (page == 2 && next == 0)) 1 else -1
        if (next != page) changePage(direction)
    }

    private fun showSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(22), dp(20), dp(22), dp(20)); background = rounded(Color.WHITE, dp(22)) }
        panel.addView(TextView(this).apply { text = "Configurações Kids Home"; textSize = 20f; setTextColor(Color.rgb(55,100,140)); gravity = Gravity.CENTER })
        panel.addView(TextView(this).apply { text = "Para usar como launcher, toque em ‘Definir como tela inicial’. Você também pode escolher Kids Home em Configurações do Android > Aplicativos padrão > App de início."; textSize = 14f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(14)) })
        val home = TextView(this).apply { text = "Definir como tela inicial"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(18), dp(12), dp(18), dp(12)); background = rounded(Color.rgb(60,155,210), dp(18)); setOnClickListener { requestHomeRole(); root.removeView(panel) } }
        panel.addView(home)
        panel.addView(TextView(this).apply { text = "Fechar"; textSize = 15f; setTextColor(Color.rgb(60,100,130)); gravity = Gravity.CENTER; setPadding(dp(18), dp(12), dp(18), dp(4)); setOnClickListener { root.removeView(panel) } })
        val p = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER); p.setMargins(dp(24), 0, dp(24), 0); root.addView(panel, p)
    }

    private fun requestHomeRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME) && !roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
                startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME), 401)
            } else showMessage("Tela inicial", "O Kids Home já está selecionado ou o sistema exige que você escolha em Aplicativos padrão.")
        } else showMessage("Tela inicial", "Abra Configurações do Android > Aplicativos padrão > App de início e selecione Kids Home Reborn.")
    }

    private fun showMessage(title: String, message: String) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(20), dp(24), dp(20)); background = rounded(Color.WHITE, dp(22)) }
        panel.addView(TextView(this).apply { text = title; textSize = 21f; setTextColor(Color.rgb(55,100,140)); gravity = Gravity.CENTER })
        panel.addView(TextView(this).apply { text = message; textSize = 14f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(16)) })
        panel.addView(TextView(this).apply { text = "Fechar"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(24), dp(10), dp(24), dp(10)); background = rounded(Color.rgb(60,155,210), dp(18)); setOnClickListener { root.removeView(panel) } })
        val p = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER); p.setMargins(dp(28), 0, dp(28), 0); root.addView(panel, p)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onPause() { super.onPause(); if (music?.isPlaying == true) music?.pause() }
    override fun onResume() { super.onResume(); if (musicEnabled) { if (music == null) startMusic() else if (music?.isPlaying == false) music?.start() } }
    override fun onDestroy() { music?.release(); music = null; sounds.release(); super.onDestroy() }
}
