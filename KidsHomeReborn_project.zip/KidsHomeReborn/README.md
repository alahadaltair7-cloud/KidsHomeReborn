# Kids Home Reborn — protótipo 0.1

Projeto Android nativo em Kotlin. É uma primeira base executável de interface, não uma reprodução completa do launcher original.

## O que já está incluído
- Cenário original recuperado dos recursos fornecidos.
- Quadros do gato marrom recuperados do pacote de recursos.
- Botões originais de aplicativos, câmera e configurações.
- Toque no gato alterna quadros; botões abrem painéis básicos.
- Identificador de pacote novo: `com.recreation.kidshome`.

## Como compilar
Abra a pasta `KidsHomeReborn` no Android Studio em um computador com Android SDK instalado, aceite a sincronização do Gradle e use **Build > Build APK(s)**.

Este ambiente de criação não possui Android SDK/Gradle configurados, então o APK não foi compilado aqui. O projeto não afirma ter sido testado num dispositivo.

## Próximas etapas
1. Ajustar composição para a proporção real da tela e comparar com capturas do launcher original.
2. Integrar sprites e animações de outros personagens.
3. Implementar seleção de personagem, cenários e lista de apps com APIs Android modernas.
4. Testar compilação e execução em Android 15.
