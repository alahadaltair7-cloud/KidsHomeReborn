package com.recreation.kidshome

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var character: ImageView
    private var frame = 0
    private val catFrames = intArrayOf(
        R.drawable.kids_character_brown_cat_01,
        R.drawable.kids_character_brown_cat_02,
        R.drawable.kids_character_brown_cat_05,
        R.drawable.kids_character_brown_cat_06,
        R.drawable.kids_character_brown_cat_07
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(105, 190, 232)
        window.navigationBarColor = Color.rgb(72, 150, 205)
        root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(125, 205, 240))

        val bg = ImageView(this).apply {
            setImageResource(R.drawable.kids_home_bg_sky_day)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Cenário original do Kids Home"
        }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        character = ImageView(this).apply {
            setImageResource(catFrames[0])
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Gato marrom"
            setOnClickListener {
                frame = (frame + 1) % catFrames.size
                setImageResource(catFrames[frame])
            }
        }
        val catParams = FrameLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.72f).toInt(),
            (resources.displayMetrics.heightPixels * 0.38f).toInt(),
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        catParams.bottomMargin = (resources.displayMetrics.heightPixels * 0.13f).toInt()
        root.addView(character, catParams)

        val title = TextView(this).apply {
            text = "Kids Home"
            textSize = 25f
            setTextColor(Color.WHITE)
            setShadowLayer(4f, 2f, 2f, Color.DKGRAY)
            gravity = Gravity.CENTER
        }
        val titleParams = FrameLayout.LayoutParams(-2, dp(52), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        titleParams.topMargin = dp(12)
        root.addView(title, titleParams)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.argb(210, 255, 255, 255), dp(24))
        }
        addImageButton(buttons, R.drawable.kids_home_button_applications, "Aplicativos") {
            showPanel("Aplicativos", "A próxima etapa será listar os aplicativos instalados.")
        }
        addImageButton(buttons, R.drawable.kids_home_button_camera, "Câmera") {
            Toast.makeText(this, "A câmera infantil será adicionada em uma próxima versão.", Toast.LENGTH_SHORT).show()
        }
        addImageButton(buttons, R.drawable.kids_home_button_settings, "Menu") {
            showPanel("Menu Kids Home", "Personagens • Cenários • Configurações")
        }
        val buttonParams = FrameLayout.LayoutParams(-1, dp(86), Gravity.BOTTOM)
        buttonParams.setMargins(dp(14), 0, dp(14), dp(14))
        root.addView(buttons, buttonParams)
        setContentView(root)
    }

    private fun addImageButton(parent: LinearLayout, res: Int, label: String, action: () -> Unit) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val image = ImageView(this).apply {
            setImageResource(res)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = label
        }
        item.addView(image, LinearLayout.LayoutParams(dp(42), dp(42)))
        val text = TextView(this).apply {
            this.text = label
            textSize = 11f
            setTextColor(Color.rgb(50, 70, 90))
            gravity = Gravity.CENTER
        }
        item.addView(text, LinearLayout.LayoutParams(-2, dp(22)))
        parent.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
    }

    private fun showPanel(title: String, message: String) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(20), dp(24), dp(20))
            background = rounded(Color.WHITE, dp(22))
        }
        panel.addView(TextView(this).apply {
            text = title
            textSize = 22f
            setTextColor(Color.rgb(55, 100, 140))
            gravity = Gravity.CENTER
        })
        panel.addView(TextView(this).apply {
            text = message
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(16))
        })
        panel.addView(TextView(this).apply {
            text = "Fechar"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(10), dp(24), dp(10))
            background = rounded(Color.rgb(60, 155, 210), dp(18))
            setOnClickListener { root.removeView(panel) }
        })
        val params = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER)
        params.setMargins(dp(28), 0, dp(28), 0)
        root.addView(panel, params)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
